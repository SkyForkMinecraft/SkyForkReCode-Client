package net.minecraft.block;

public class BlockRedFlower extends BlockFlower
{
    public BlockFlower.EnumFlowerColor getBlockType()
    {
        return BlockFlower.EnumFlowerColor.RED;
    }
}
