package javax.vecmath;

import java.io.Serializable;

public class Matrix4f implements Serializable, Cloneable {
	public Matrix4f(org.lwjgl.util.vector.Matrix4f matrix4f) {
	}
}

